package controllers;

import play.mvc.*;

public class Module extends Controller {
    
    public static void index() {}
}
